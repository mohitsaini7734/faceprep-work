# Failover test procedure

> Use only in your isolated local educational replica set. Do not test failure on production systems.

1. Connect to the replica set and run `rs.status()`.
2. Identify the member whose `stateStr` is `PRIMARY`.
3. Stop that `mongod` process from its terminal (Ctrl+C).
4. Wait for the remaining voting members to elect a new primary.
5. Connect to an available member and run `rs.status()` again.
6. Verify one reachable member is now `PRIMARY`; the other available member should be `SECONDARY`.
7. Restart the stopped process with the same replica-set name, port, and data directory.
8. Wait for it to rejoin and verify its state in `rs.status()`.

## Expected observations
- The old primary becomes unavailable.
- The remaining voting majority can elect a new primary.
- The restarted node catches up from the oplog if the needed history is still available.
- If a majority is unavailable, the set cannot elect a primary and writes will not proceed normally.

## Troubleshooting
- Check that each node uses a separate data directory.
- Confirm all processes use `--replSet rs0`.
- Confirm the advertised hostnames/ports are reachable by all replica-set members.
- Inspect each `mongod` log if members remain in `STARTUP` or `UNKNOWN`.
