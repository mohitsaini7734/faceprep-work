// 05_replication_checks.js — run against a replica-set connection
use("MongoPerformanceProject");

print("Replica set status:");
printjson(rs.status());

// Current connection's role (hello is the modern command)
print("Hello response:");
printjson(db.adminCommand({ hello: 1 }));

// Majority-acknowledged write
print("Majority write:");
printjson(db.products.insertOne(
  {
    productId: 999,
    name: "Replication Test Item",
    category: "Testing",
    price: 1,
    stock: 1,
    tags: ["replication-test"]
  },
  { writeConcern: { w: "majority", wtimeout: 5000 } }
));

// Oplog is stored in local.oplog.rs; query it on a replica-set member.
print("Recent oplog entries:");
printjson(
  db.getSiblingDB("local").oplog.rs
    .find()
    .sort({ $natural: -1 })
    .limit(5)
    .toArray()
);

// Read preference examples (driver/shell behavior can vary by version).
print("Primary read preference example:");
printjson(db.products.find({ category: "Electronics" }).readPref("primary").toArray());

print("Secondary-preferred read preference example:");
printjson(db.products.find({ category: "Electronics" }).readPref("secondaryPreferred").toArray());
