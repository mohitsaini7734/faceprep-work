// 02_indexes.js — index types and hidden-index demonstration
use("MongoPerformanceProject");

// Clear existing non-_id indexes so the demonstration is repeatable.
db.products.dropIndexes();

// Single-field index
db.products.createIndex({ category: 1 }, { name: "category_asc" });

// Compound index: equality field followed by price sort/range field
db.products.createIndex({ category: 1, price: -1 }, { name: "category_price" });

// Multikey index because tags is an array
db.products.createIndex({ tags: 1 }, { name: "tags_multikey" });

// Unique index for product IDs
db.products.createIndex({ productId: 1 }, { unique: true, name: "productId_unique" });

print("Indexes created:");
printjson(db.products.getIndexes());

// Hidden indexes are maintained but ignored by the query planner.
db.products.hideIndex("category_asc");
print("category_asc hidden; inspect query plan in script 03.");
printjson(db.products.getIndexes());

db.products.unhideIndex("category_asc");
print("category_asc unhidden.");
