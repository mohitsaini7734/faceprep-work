// 03_query_analysis.js — query plans and validation
use("MongoPerformanceProject");

print("Query plan for category filter:");
printjson(
  db.products.find({ category: "Electronics" })
    .explain("executionStats")
);

print("Query plan for category + price range:");
printjson(
  db.products.find({
    category: "Electronics",
    price: { $gte: 20000 }
  }).sort({ price: -1 }).explain("executionStats")
);

print("Multikey query plan:");
printjson(
  db.products.find({ tags: "office" }).explain("executionStats")
);

print("Indexes currently available:");
printjson(db.products.getIndexes());

// Optional index usage statistics, where supported:
print("Index usage statistics:");
printjson(db.products.aggregate([{ $indexStats: {} }]).toArray());
