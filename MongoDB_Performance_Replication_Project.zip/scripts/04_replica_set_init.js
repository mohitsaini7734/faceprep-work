// 04_replica_set_init.js — run once on localhost:27017 using mongosh
// All three mongod processes must already be running with --replSet rs0.
rs.initiate({
  _id: "rs0",
  members: [
    { _id: 0, host: "localhost:27017" },
    { _id: 1, host: "localhost:27018" },
    { _id: 2, host: "localhost:27019" }
  ]
});

print("Replica set initialization requested. Wait for election, then run rs.status().");
