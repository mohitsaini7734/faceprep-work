// 01_setup_data.js — run in mongosh
use("MongoPerformanceProject");

db.products.drop();

db.products.insertMany([
  { productId: 101, name: "Laptop", category: "Electronics", price: 55000, stock: 12, tags: ["computer", "office"] },
  { productId: 102, name: "Phone", category: "Electronics", price: 25000, stock: 30, tags: ["mobile", "electronics"] },
  { productId: 103, name: "Chair", category: "Furniture", price: 4500, stock: 20, tags: ["office", "furniture"] },
  { productId: 104, name: "Monitor", category: "Electronics", price: 12000, stock: 15, tags: ["display", "office"] },
  { productId: 105, name: "Desk", category: "Furniture", price: 9000, stock: 8, tags: ["office", "wood"] },
  { productId: 106, name: "Headphones", category: "Accessories", price: 3500, stock: 40, tags: ["audio", "electronics"] },
  { productId: 107, name: "Keyboard", category: "Accessories", price: 1800, stock: 50, tags: ["computer", "office"] },
  { productId: 108, name: "Tablet", category: "Electronics", price: 32000, stock: 18, tags: ["mobile", "display"] }
]);

print("Sample data created:");
print("Documents: " + db.products.countDocuments());
printjson(db.products.find().toArray());
