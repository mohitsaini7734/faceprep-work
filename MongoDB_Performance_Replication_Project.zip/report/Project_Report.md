# MongoDB Performance Optimization and Replica Set Monitoring System

## 1. Abstract
This project demonstrates database performance optimization and availability features in MongoDB. It uses single-field, compound, multikey, unique, and hidden indexes to examine query execution. It also configures a three-member replica set and demonstrates primary/secondary roles, read preference, majority write concern, oplog synchronization, health monitoring, and failover.

## 2. Problem Statement
Queries can become inefficient when a collection grows, and a single database server can become a point of failure. The project explores indexing to reduce unnecessary document scans and replication to improve redundancy and service availability.

## 3. Objectives
- Create and compare common MongoDB index types.
- Inspect query plans using `explain("executionStats")`.
- Demonstrate hidden indexes and index usage statistics.
- Configure a local three-member replica set.
- Understand read preference and write concern.
- Inspect replica-set status and oplog entries.
- Test primary election after a simulated failure.

## 4. Tools and Technologies
- MongoDB Community Server
- MongoDB Shell (`mongosh`)
- JavaScript-based MongoDB shell scripts
- MongoDB Compass (optional, for visual inspection)
- Windows/macOS/Linux local environment

## 5. System Design
The indexing module operates on a `products` collection. Queries are tested with and without relevant indexes, and the explain output is inspected. The replication module uses one primary and two secondary members. Writes are sent to the primary, operations are recorded in the oplog, and secondary members replicate those operations.

## 6. Implementation
### 6.1 Indexing
The project creates:
- A single-field index on `category`.
- A compound index on `category` and `price`.
- A multikey index on the array field `tags`.
- A unique index on `productId`.
- A hidden/unhidden index demonstration.

The query planner is examined using `explain("executionStats")`. `IXSCAN` indicates an index scan and `COLLSCAN` indicates a collection scan. `totalDocsExamined`, `totalKeysExamined`, and `executionTimeMillis` are recorded for comparison. Small sample collections may not show meaningful timing gains, so a larger dataset is recommended for performance benchmarking.

### 6.2 Replication
Three local `mongod` processes run as members of replica set `rs0`. The primary accepts writes; secondaries replicate changes. The project uses `rs.status()` and the `hello` command to inspect member roles, demonstrates `readPref()`, and issues a write with `w: "majority"`.

### 6.3 Oplog and Failover
Recent records from `local.oplog.rs` are inspected. For failover testing, the primary process is stopped and the remaining voting members are observed electing a new primary. The old node is restarted and allowed to rejoin.

## 7. Testing and Results
Record the actual output from your own environment in the following table.

| Test | Expected observation | Actual result |
|---|---|---|
| Create indexes | Index names appear in `getIndexes()` | Fill after running |
| Query explain | Winning plan and execution statistics are shown | Fill after running |
| Hidden index | Hidden index is not selected by planner | Fill after running |
| Replica status | One PRIMARY and two SECONDARY members | Fill after running |
| Majority write | Write is acknowledged if majority conditions are met | Fill after running |
| Oplog inspection | Recent operation entries are returned | Fill after running |
| Primary failure | New primary elected when voting majority is available | Fill after running |

## 8. Limitations
- Results depend on MongoDB version, dataset size, hardware, and workload.
- A small dataset may be served by a collection scan even when an index exists.
- Secondary reads may be stale.
- A local replica set is for learning and does not represent a secure production deployment.

## 9. Future Enhancements
- Build a dashboard using Python and a MongoDB driver.
- Add charts for query execution metrics and replication lag.
- Add alerts for unhealthy replica-set members.
- Use a larger generated dataset for repeatable performance tests.
- Configure authentication, TLS, backups, and production monitoring.

## 10. Conclusion
The project provides practical experience with MongoDB indexing, query-plan analysis, replication, read/write consistency options, oplog synchronization, replica-set health checks, and automatic primary elections. It shows how indexes and replication address different goals: query efficiency and availability.

## References
- https://www.mongodb.com/docs/manual/indexes/
- https://www.mongodb.com/docs/manual/reference/explain-results/
- https://www.mongodb.com/docs/manual/replication/
- https://www.mongodb.com/docs/manual/core/read-preference/
- https://www.mongodb.com/docs/manual/reference/write-concern/
- https://www.mongodb.com/docs/manual/core/replica-set-oplog/
