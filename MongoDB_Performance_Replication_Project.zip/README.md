# MongoDB Performance Optimization and Replica Set Monitoring

## Project overview
This project demonstrates MongoDB index optimization and replica-set monitoring using `mongosh`.
It includes sample data, index experiments, replication setup, health checks, and failover testing.

## Requirements
- MongoDB Community Server and `mongosh`
- Windows, macOS, or Linux
- For replication experiments: three local `mongod` processes using separate data directories

## Project structure
- `scripts/01_setup_data.js` — database and sample dataset
- `scripts/02_indexes.js` — single-field, compound, multikey, hidden and unique indexes
- `scripts/03_query_analysis.js` — explain plans and index validation
- `scripts/04_replica_set_init.js` — initialize a local three-node replica set
- `scripts/05_replication_checks.js` — status, oplog, read preference, and write concern examples
- `scripts/06_failover_test.md` — safe manual failover test procedure
- `report/Project_Report.md` — ready-to-edit project report

## Run the indexing demo
Open `mongosh` and run:
```javascript
load("scripts/01_setup_data.js")
load("scripts/02_indexes.js")
load("scripts/03_query_analysis.js")
```
Run commands from the project folder, or use absolute paths in `load()`.

## Run the replication demo (local lab only)
1. Start three `mongod` processes with the same replica-set name (`rs0`) and ports `27017`, `27018`, and `27019`.
2. Ensure each process has a different data directory.
3. Connect to port 27017 with `mongosh`.
4. Run `load("scripts/04_replica_set_init.js")`.
5. Wait for election, then run `load("scripts/05_replication_checks.js")`.

Example Windows data directories:
```powershell
mkdir C:\data\rs0-1
mkdir C:\data\rs0-2
mkdir C:\data\rs0-3
```
Start each in its own terminal:
```powershell
mongod --replSet rs0 --port 27017 --dbpath C:\data\rs0-1
mongod --replSet rs0 --port 27018 --dbpath C:\data\rs0-2
mongod --replSet rs0 --port 27019 --dbpath C:\data\rs0-3
```
Then connect:
```powershell
mongosh --port 27017
```

**Important:** This is a local educational setup. Do not expose these unauthenticated test instances to a network or use this configuration in production. For a real deployment, configure authentication, TLS, secure networking, backups, and appropriate storage/journaling.

## What to capture for submission
- `getIndexes()` output
- `explain("executionStats")` output before/after indexes
- `rs.status()` showing one PRIMARY and two SECONDARY members
- Recent oplog entries
- Evidence of successful failover after stopping the primary
